package com.tumodulo.sensihack

import android.content.Context
import android.content.SharedPreferences
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XC_MethodHook

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.dts.freefireth") return

        XposedBridge.log("SensiHack: Free Fire detectado")

        // Obtener preferencias
        val prefs = lpparam.appContext.getSharedPreferences("sensi_config", Context.MODE_PRIVATE)
        val sensitivityFactor = prefs.getFloat("vertical_sens", 1.0f)
        val isAimLockEnabled = prefs.getBoolean("aim_lock_enabled", true)
        val HEAD_LEVEL_Y = 0.75f // Establece el nivel de la cabeza (en porcentaje de pantalla)

        // Hook para sensibilidad vertical
        try {
            XposedHelpers.findAndHookMethod(
                "com.garena.game.input.CameraInputHandler",
                lpparam.classLoader,
                "setVerticalSensitivity",
                Float::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val original = param.args[0] as Float
                        param.args[0] = original * sensitivityFactor
                        XposedBridge.log("SensiHack: Cambiando sensibilidad a ${param.args[0]}")
                    }
                }
            )

            // Hook para movimiento de cámara y limitar la mira
            XposedHelpers.findAndHookMethod(
                "com.garena.game.input.CameraInputHandler",
                lpparam.classLoader,
                "moveCameraVertically",
                Float::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val currentCameraY = param.args[0] as Float

                        // Si la opción de freno de mira está activada, limitamos la cámara
                        if (isAimLockEnabled && currentCameraY > HEAD_LEVEL_Y) {
                            param.args[0] = HEAD_LEVEL_Y
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            XposedBridge.log("SensiHack: Error al hookear - ${e.message}")
        }
    }
}